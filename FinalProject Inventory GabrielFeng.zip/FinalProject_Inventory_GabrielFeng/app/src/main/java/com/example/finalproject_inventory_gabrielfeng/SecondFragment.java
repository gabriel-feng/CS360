package com.example.finalproject_inventory_gabrielfeng;

import android.app.PendingIntent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.finalproject_inventory_gabrielfeng.databinding.FragmentSecondBinding;

import java.util.ArrayList;
import java.util.List;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;
    private List<InventoryItem> items;
    private EditText newItemName;
    private EditText newItemStock;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentSecondBinding.inflate(inflater, container, false);

        newItemName = (EditText) binding.getRoot().findViewById(R.id.editTextItemName);
        newItemStock = (EditText) binding.getRoot().findViewById(R.id.editTextItemStock);

        items = new ArrayList<>();

        String[] itemNames = getContext().getResources().getStringArray(R.array.itemNames);
        int[] itemStock = getContext().getResources().getIntArray(R.array.itemStock);

        for(int i = 0; i < itemNames.length; i++) {
            items.add(new InventoryItem(itemNames[i], itemStock[i]));
        }

        ItemAdapter adapter = new ItemAdapter(getContext(), R.layout.item_layout, items);
        ListView listView = binding.getRoot().findViewById(R.id.inventoryDisplay);
        listView.setAdapter(adapter);

        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.addData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                items.add(new InventoryItem(newItemName.getText().toString(),
                        Integer.parseInt(newItemStock.getText().toString())));
            }
        });

        binding.toSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_ThirdFragment);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void smsSendMessage(View view) {
        EditText phoneNumber = binding.getRoot().findViewById(R.id.phoneNumber);
        // Set the destination phone number to the string in editText.
        String destinationAddress = phoneNumber.getText().toString();
        // Get the text of the SMS message.
        String smsMessage = "An item has run out of stock!";
        // Set the service center address if needed, otherwise null.
        String scAddress = null;
        // Set pending intents to broadcast
        // when message sent and when delivered, or set to null.
        PendingIntent sentIntent = null, deliveryIntent = null;
        // Use SmsManager.
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage
                (destinationAddress, scAddress, smsMessage,
                        sentIntent, deliveryIntent);
    }
}
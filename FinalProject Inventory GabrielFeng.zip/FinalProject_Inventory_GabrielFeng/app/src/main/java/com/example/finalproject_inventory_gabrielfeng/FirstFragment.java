package com.example.finalproject_inventory_gabrielfeng;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.finalproject_inventory_gabrielfeng.databinding.FragmentFirstBinding;

import java.util.ArrayList;
import java.util.List;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;
    private List<String> usernames;
    private List<String> passwords;
    private EditText username;
    private EditText password;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentFirstBinding.inflate(inflater, container, false);

        username = binding.getRoot().findViewById(R.id.loginUsername);
        password = binding.getRoot().findViewById(R.id.loginPassword);

        usernames = new ArrayList<>();
        passwords = new ArrayList<>();

        String[] usernames_a = getContext().getResources().getStringArray(R.array.usernames);
        String[] passwords_a = getContext().getResources().getStringArray(R.array.passwords);
        for (int i = 0; i < usernames_a.length; i++) {
            usernames.add(usernames_a[i]);
            passwords.add(passwords_a[i]);
        }

        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Toast invalidLogin = Toast.makeText(getActivity(), "Invalid Login", Toast.LENGTH_SHORT);
        Toast invalidRegister = Toast.makeText(getActivity(),
                "Please choose a valid username and password", Toast.LENGTH_SHORT);

        binding.login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!usernames.contains(username.getText().toString()) ||
                        !passwords.contains(password.getText().toString())) {
                    invalidLogin.show();
                    return;
                }
                if (usernames.indexOf(username.getText().toString()) !=
                        passwords.indexOf(password.getText().toString())) {
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment);
                } else {
                    invalidLogin.show();
                }
            }
        });

        binding.register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (username.getText().toString().equals("") ||
                        password.getText().toString().equals("")) {
                    invalidRegister.show();
                    return;
                }
                usernames.add(username.getText().toString());
                passwords.add(password.getText().toString());
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}
package com.example.finalproject_inventory_gabrielfeng;

public class InventoryItem {
    private String name;
    private int stock;

    public InventoryItem() {}

    public InventoryItem(String name, int stock) {
        this.name = name;
        this.stock = stock;
    }

    public String getName() {
        return name;
    }

    public int getStock() {
        return stock;
    }
}

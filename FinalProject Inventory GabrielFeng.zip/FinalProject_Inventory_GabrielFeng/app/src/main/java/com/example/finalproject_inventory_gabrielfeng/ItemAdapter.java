package com.example.finalproject_inventory_gabrielfeng;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class ItemAdapter extends ArrayAdapter<InventoryItem> {
    private List<InventoryItem> items;

    public ItemAdapter(@NonNull Context context, int resource, List<InventoryItem> items) {
        super(context, resource);
        this.items = items;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        int phraseIndex = position;
        if(convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_layout,
                    parent, false);
        }
        EditText itemName = convertView.findViewById(R.id.editTextName);
        EditText itemStock = convertView.findViewById(R.id.editTextNumber);

        itemName.setText(items.get(position).getName());
        itemStock.setText(items.get(position).getStock());

        return convertView;
    }
}
